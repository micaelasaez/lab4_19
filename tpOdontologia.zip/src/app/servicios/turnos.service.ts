import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/auth';
import { AngularFirestore } from '@angular/fire/firestore';
import { map } from 'rxjs/internal/operators/map';
import { Usuario } from './auth.service';

export interface Turno {
  // horario: string;
  especialista: string;
  fecha: string;
  email: string;
  id?: string;
  presente: boolean;
  cerrado: boolean;
  reseña: string;
}

@Injectable({
  providedIn: 'root'
})
export class TurnosService {

  constructor(private firestore: AngularFirestore) { }

  public AddTurno(turno: Turno) {
    return this.firestore.collection('turnos').add(turno).then( (res) => {
      console.log('Agregado');
    });
  }
  public GetTurnos() {
    return this.firestore.collection('turnos').snapshotChanges().pipe(map((fotos) => {
      return fotos.map((a) => {
        const data = a.payload.doc.data() as Turno;
        data.id = a.payload.doc.id;
        return data;
      });
    }));
  }
  public UpdateTurno(turno: Turno) {
    return this.firestore.collection('turnos').doc(turno.id).set(turno);
  }
}
