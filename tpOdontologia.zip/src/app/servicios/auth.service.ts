import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/auth';
import { AngularFirestore } from '@angular/fire/firestore';
import { map } from 'rxjs/internal/operators/map';

export interface Usuario {
  id?: string;
  email: string;
  perfil: string;
  foto: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  public usuario = null;

  constructor(private firebaseAuth: AngularFireAuth, private firestore: AngularFirestore) { }

  public UsuarioActual() {
    return this.firebaseAuth.auth.currentUser.email;
  }
  public CrearUsuario(usuario: any) {
    return this.firebaseAuth.auth.createUserWithEmailAndPassword(usuario.email, usuario.pass).then( (ress) => {
      console.log(ress);
      // this.EnviarVerificacion(mail);
      this.firestore.collection('usuarios-odontologica').add({
        email: usuario.email,
        perfil: usuario.perfil,
        foto: usuario.foto
      }).then( (res) => {
        console.log('Agregado');
      });
    });
  }
  private EnviarVerificacion(mail: string) {
    this.firebaseAuth.auth.currentUser.sendEmailVerification().then( (res) => {
      console.log(res);
    });
  }
  public IniciarSesion(mail: string, pass: string) {
    return this.firebaseAuth.auth.signInWithEmailAndPassword(mail, pass).then(usuarioLogeado => {
      this.usuario = usuarioLogeado.user.email;
      /*if (res.user.emailVerified) {
          return true;
        } else {
          return false;
        }*/
    });
  }

  public LogOut() {
    this.usuario = null;
    this.firebaseAuth.auth.signOut();
  }

  public GetUsuarios() {
    return this.firestore.collection('usuarios-odontologica').snapshotChanges().pipe(map((fotos) => {
      return fotos.map((a) => {
        const data = a.payload.doc.data() as Usuario;
        data.id = a.payload.doc.id;
        return data;
      });
    }));
  }

  public UpdateUsuario(us: Usuario) {
    return this.firestore.collection('usuarios-odontologica').doc(us.id).set(us);
  }

}
