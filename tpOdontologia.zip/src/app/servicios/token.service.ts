import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AuthService } from './auth.service';
import { AngularFireAuth } from '@angular/fire/auth';

@Injectable({
  providedIn: 'root'
})
export class TokenService implements CanActivate {
  constructor(private router: Router, private firebaseAuth: AuthService) { }

  canActivate(
    route: import ('@angular/router').ActivatedRouteSnapshot,
    state: import ('@angular/router').RouterStateSnapshot): boolean
    | import ('@angular/router').UrlTree | import ('rxjs').Observable<boolean
    | import ('@angular/router').UrlTree> | Promise<boolean | import ('@angular/router').UrlTree> {
      if (this.firebaseAuth.usuario !== null) {
        console.log('guard true');
        return true;
      } else  {
        console.log('guard false');
        this.router.navigate(['/login']);
        return false;
      }
  }
}
