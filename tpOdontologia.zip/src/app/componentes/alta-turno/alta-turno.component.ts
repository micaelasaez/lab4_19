import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { TurnosService, Turno } from 'src/app/servicios/turnos.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AuthService, Usuario } from 'src/app/servicios/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-alta-turno',
  templateUrl: './alta-turno.component.html',
  styleUrls: ['./alta-turno.component.css']
})
export class AltaTurnoComponent implements OnInit {
  @Output() actualizar = new EventEmitter<Turno>();
  public formulario: FormGroup;
  public isLoggueado: boolean;
  public items  = []; // ESPECIALISTAS
  public user: Usuario;
  public clientes = [];

  constructor(private router: Router, private authServ: AuthService, private turnosServ: TurnosService) { }

  ngOnInit() {
    this.authServ.GetUsuarios().subscribe( (data) => {
      data.forEach(element => {
        if (element.email == this.authServ.usuario) {
          this.user = element;
        }
        if (element.perfil === 'especialista') {
          this.items.push(element);
        } else if (element.perfil === 'cliente') {
          this.clientes.push(element);
        }
      });
    });
    this.formulario = new FormGroup({
      especialista: new FormControl('', Validators.required),
      fecha: new FormControl('', Validators.required),
      cliente: new FormControl('')
    });
  }

  public Ingresar() {
    console.log(this.formulario.value);
    const turnoAux: Turno = {
      cerrado : false,
      email : this.authServ.usuario,
      fecha : this.formulario.value.fecha,
      especialista : this.formulario.value.especialista,
      presente : false,
      reseña : ''
    };
    if (this.user.perfil === 'recepcionista') {
      turnoAux.email = this.formulario.value.cliente;
    }
    this.turnosServ.AddTurno(turnoAux).then( () => {
      this.actualizar.emit(turnoAux);
      this.formulario.value.cliente = '';
      this.formulario.value.especialista = '';
      alert('Turno agregado!');
    });
  }
}
