import { Component, OnInit } from '@angular/core';
import { AuthService, Usuario } from 'src/app/servicios/auth.service';
import { Router } from '@angular/router';
import { TurnosService, Turno } from 'src/app/servicios/turnos.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  public user: Usuario;
  public turnos = [];
  public mostrarTextArea = false;
  public resena = '';
  public turno: Turno;
  public turnosCliente = [];
  public usuarios = [];

  constructor(private authserv: AuthService, private router: Router, private turnosServ: TurnosService) { }

  ngOnInit() {
    this.ActualizarLista();
    this.authserv.GetUsuarios().subscribe( (data) => {
      this.usuarios = data;
      data.forEach(element => {
        if (element.email === this.authserv.usuario) {
          this.user = element;
        }
      });
    });
  }
  public AddUsuario() {
    this.router.navigate(['/alta-usuario']);
  }
  public Atender(turno: Turno) {
    this.turno = turno;
    this.mostrarTextArea = true;
  }
  public GuardarRes() {
    if (this.resena != '') {
      alert('Reseña guardada!');
      this.turno.reseña = this.resena;
      this.turno.cerrado = true;
      this.turno.presente = true;
      this.mostrarTextArea = false;
      this.turnosServ.UpdateTurno(this.turno).then( () => {
        this.ActualizarLista();
      });
    }
  }
  public ActualizarLista() {
    // console.log('actualizarlista');
    this.turnos = [];
    this.turnosServ.GetTurnos().subscribe( (data) => {
      data.forEach(element => {
        if (element.email === this.authserv.usuario) {
          this.turnosCliente.push(element);
        }
        if (!element.cerrado) {
          this.turnos.push(element);
        }
      });
    });
  }
}
