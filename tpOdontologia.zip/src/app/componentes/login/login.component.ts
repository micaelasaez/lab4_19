import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/servicios/auth.service';
import { timer } from 'rxjs/internal/observable/timer';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public formularioLogin: FormGroup;
  public error = '';

  constructor(private router: Router, private authServ: AuthService) { }

  ngOnInit() {
    this.formularioLogin = new FormGroup({
      email: new FormControl('', [ Validators.required, Validators.email ]),
      pass: new FormControl('', Validators.required)
    });
  }

  public Ingresar() {
    // console.log(this.formularioLogin.value);
    this.authServ.IniciarSesion(this.formularioLogin.value.email, this.formularioLogin.value.pass).then( (res) => {
      this.router.navigate(['/home']);
      // if (res) {
      //   this.router.navigate(['/home']);
      // } else {
      //   alert('no verificó email');
      // }
    }).catch( (err) => {
      // console.log(err);
      if (err.code == 'auth/user-not-found') {
        this.error = 'Email no registrado!';
      } else if (err.code == 'auth/wrong-password') {
        this.error = 'Contraseña incorrecta!';
      }
      timer(4000).subscribe(() => {
        this.error = '';
      });
    });
  }
  public SignUp() {
    this.router.navigate(['/alta-usuario']);
  }
}
