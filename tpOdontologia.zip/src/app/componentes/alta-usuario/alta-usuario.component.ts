import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/servicios/auth.service';

@Component({
  selector: 'app-alta-usuario',
  templateUrl: './alta-usuario.component.html',
  styleUrls: ['./alta-usuario.component.css']
})
export class AltaUsuarioComponent implements OnInit {
  public isLoggueado = false;
  public formularioLogin: FormGroup;

  constructor(private router: Router, private authServ: AuthService) { }

  ngOnInit() {
    if (this.authServ.usuario != null) {
      this.isLoggueado = true;
    } else  {
      this.isLoggueado = false;
    }
    this.formularioLogin = new FormGroup({
      email: new FormControl('', [ Validators.required, Validators.email ]),
      pass: new FormControl('', Validators.required),
      perfil: new FormControl('', Validators.required),
      foto: new FormControl('', Validators.required)
    });
  }

  public Ingresar() {
    console.log(this.formularioLogin.value);
    this.authServ.CrearUsuario(this.formularioLogin.value)
      .then( (res) => {
        if (this.isLoggueado) {
          this.router.navigate(['/home']);
        } else {
          this.router.navigate(['/login']);
        }
        /*if (res) {
          this.router.navigate(['/home']);
        } else {
          alert('no verificó email');
        }*/
      });
  }
}
