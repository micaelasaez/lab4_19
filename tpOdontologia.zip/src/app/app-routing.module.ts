import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TokenService } from './servicios/token.service';
import { AltaUsuarioComponent } from './componentes/alta-usuario/alta-usuario.component';
import { LoginComponent } from './componentes/login/login.component';
import { HomeComponent } from './componentes/home/home.component';
import { MenuComponent } from './componentes/menu/menu.component';
import { AltaTurnoComponent } from './componentes/alta-turno/alta-turno.component';

const routes: Routes = [
  { path: 'alta-turno', component: AltaTurnoComponent, canActivate: [ TokenService ] },
  { path: 'alta-usuario', component: AltaUsuarioComponent },
  { path: 'login', component: LoginComponent },
  { path: 'menu', component: MenuComponent, canActivate: [ TokenService ] },
  { path: 'home', component: HomeComponent, canActivate: [ TokenService ] },
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: '**', redirectTo: '/login', pathMatch: 'full' }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
