import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './pages/home/home.component';

// Servicios
import { ServerService } from './services/server.service';

// HttpClientModule
import { HttpClientModule } from '@angular/common/http';

// Angular Material
import { MatGridListModule, } from '@angular/material';
import { ListadoComponent } from './pages/listado/listado.component';

// File Drop
import { FileDropModule } from 'ngx-file-drop';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ListadoComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,

    // HttpClientModule
    HttpClientModule,

    // Angular Material
    MatGridListModule,

    // File Drop
    FileDropModule,
  ],
  providers: [
    // Servicios
    ServerService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
