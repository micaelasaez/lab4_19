import { Component, OnInit } from '@angular/core';
import { ServerService } from 'src/app/services/server.service';
import { MatGridList } from '@angular/material';

@Component({
  selector: 'app-listado',
  templateUrl: './listado.component.html',
  styleUrls: ['./listado.component.css']
})
export class ListadoComponent implements OnInit {
  public listadoFotos: string[];
  constructor(private uploadService: ServerService) { }

  ngOnInit() {
    this.listadoFotos = null;
    this.ObtenerFotos();
  }

  public ObtenerFotos(): void {
    this.uploadService.ObtenerFotos().subscribe((data: any) => {
      this.listadoFotos = data;
      console.log(data);
    });
  }
}
