import { Component, OnInit } from '@angular/core';
import { ServerService } from 'src/app/services/server.service';

// Para FileDrop
import { UploadEvent, UploadFile, FileSystemFileEntry, FileSystemDirectoryEntry } from 'ngx-file-drop';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  private archivosElegidos: File;
  // Para File Drop
  // public files: UploadFile[] = [];

  constructor(private uploadService: ServerService) { }

  ngOnInit() {
    this.archivosElegidos = null;
  }

  public ElegirArchivo(event: any): void {
    // Solo funciona para UN archivo.
    this.archivosElegidos = event.target.files[0] as File;
    console.log('Hice cambio de archivo en el input');
  }

  public SubirArchivo(): void {
    this.uploadService.SubirArchivo(this.archivosElegidos).subscribe((data: any) => {
      console.log(data);
    });
  }

  // Para File Drop
  public dropped(event: UploadEvent) {
    // this.files = event.files;

    for (const droppedFile of event.files) {
      // Es un archivo?
      if (droppedFile.fileEntry.isFile) {
        const fileEntry = droppedFile.fileEntry as FileSystemFileEntry;
        fileEntry.file((file: File) => {

          // Aquí puedo acceder al archivo real
          console.log(droppedFile.relativePath, file);

          this.SubirArchivoDrop(file);
        });
      } else {
        // Si fue un directorio (directorios vacios, en caso contrario solo archivos)
        const fileEntry = droppedFile.fileEntry as FileSystemDirectoryEntry;
        console.log(droppedFile.relativePath, fileEntry);
      }
    }
  }

  /* public fileOver(event) {
    console.log(event);
  }

  public fileLeave(event) {
    console.log(event);
  } */

  public SubirArchivoDrop(file: File): void {
    this.uploadService.SubirArchivo(file).subscribe((data: any) => {
      console.log(data);
    });
  }
}
